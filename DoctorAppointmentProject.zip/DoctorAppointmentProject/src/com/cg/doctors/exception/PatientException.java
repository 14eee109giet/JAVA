package com.cg.doctors.exception;

public class PatientException extends Exception {

	public PatientException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

}
