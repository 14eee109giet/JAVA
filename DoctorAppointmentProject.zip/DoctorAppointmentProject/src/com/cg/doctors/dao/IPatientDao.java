package com.cg.doctors.dao;

import com.cg.doctors.bean.PatientBean;
import com.cg.doctors.exception.PatientException;

public interface IPatientDao {

	int addPatientDetails(PatientBean doctorAppointment);

	PatientBean getPatientDetails(int appointmentId) throws PatientException;
}
