package com.cg.doctors.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.doctors.bean.PatientBean;
import com.cg.doctors.exception.PatientException;
import com.cg.pms.Util.DatabaseConnection;

public class PatientDao implements IPatientDao {
	Connection con;

	public PatientDao() {
		try {
			con = DatabaseConnection.getConnection();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public int addPatientDetails(PatientBean patient) {
		String sql = "insert into patient values(?,?,?,?,?,?)";
		patient.setPatient_id(generatePatientId());
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, patient.getPatient_id());
			ps.setString(2, patient.getPatient_name());
			ps.setInt(3, patient.getAge());
			ps.setString(4, patient.getPhone());
			ps.setString(5, patient.getDescription());
			ps.setDate(6, Date.valueOf(patient.getConsultation_date()));
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return patient.getPatient_id();
	}

	int generatePatientId() {
		int patient_id = 0;
		String sql = "select patient_id_seq.nextval from dual";
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			if (rs.next())
				patient_id = rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return patient_id;
	}

	@Override
	public PatientBean getPatientDetails(int patientId) throws PatientException {
		PatientBean patient = null;
		String sql = "select * from patient where patient_Id=?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, patientId);
			ResultSet set = ps.executeQuery();
			while (set.next()) {
				patient = new PatientBean();
				patient.setPatient_id(set.getInt(1));
				patient.setPatient_name(set.getString(2));
				patient.setAge(set.getInt(3));
				patient.setPhone(set.getString(4));
				patient.setDescription(set.getString(5));
				patient.setConsultation_date(set.getDate(6).toLocalDate());
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(patient==null) {
			throw new PatientException("There is no patient with this id");
		}
		return patient;
	}

}
