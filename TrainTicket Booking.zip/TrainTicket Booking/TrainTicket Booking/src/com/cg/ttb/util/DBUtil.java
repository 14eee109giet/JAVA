package com.cg.ttb.util;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {

	public static Connection getConnection() throws IOException {
		Connection con = null;
		String url1 = "jdbc:oracle:thin:@//localhost:1521/XE";
		String user1 = "SYSTEM";
		String pwd1 = "9510";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println("Driver is not loaded sucessfully");
			e.printStackTrace();
		}
		try {
			con = DriverManager.getConnection(url1, user1, pwd1);
		} catch (SQLException e) {
			System.out.println("Connection is not established");
			e.printStackTrace();
		}
		return con;
	}

}
