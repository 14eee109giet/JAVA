package com.cg.ttb.dao;

import java.util.List;

import com.cg.ttb.beans.BookingBean;
import com.cg.ttb.beans.TrainBean;
import com.cg.ttb.exception.TrainException;

public interface ITrainDao {

	List<TrainBean> retrieveTrainDetails() throws TrainException;

	int bookTicket(BookingBean bookingbean) throws TrainException;

	int generateBookingId()  throws TrainException;

}
